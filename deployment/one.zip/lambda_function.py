import boto3
from botocore.exceptions import ClientError
import os
import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
  s3 = boto3.client('s3')
  bucket = os.environ['BUCKET_ONE']
  key = 'data.txt'
  body = 'Hello, from lambda'

  s3.put_object(Bucket=bucket, Key=key, Body=body)
  return {'status': 'uploaded', 'bucket': bucket, 'key': key}
