import boto3
import os
import logging
import random

# Logger beállítása INFO szintre
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
  s3 = boto3.client('s3')
  bucket = os.environ['BUCKET_ONE']
  key = 'data.txt'
  body = 'Hello, from lambda'

  try:
    logger.info("Lambda function started")

    # Random hibadobás 30% eséllyel
    if random.random() < 0.3:
      logger.debug("Random error triggered")
      raise Exception("Random error triggered")

    # Fájl feltöltése az S3-ba
    s3.put_object(Bucket=bucket, Key=key, Body=body)
    logger.info(f"Successfully uploaded to bucket: {bucket}, key: {key}")
    return {'status': 'uploaded', 'bucket': bucket, 'key': key}

  # Tovább dobja a hibát, hogy CloudWatch lássa es triggereljen sns riasztást
  except Exception as e:
      logger.error(f"Error occurred: {e}")
      raise e

