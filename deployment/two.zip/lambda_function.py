import boto3
import os

def handler(event, context):
    s3 = boto3.client('s3')
    source_bucket = os.environ['BUCKET_ONE']
    target_bucket = os.environ['BUCKET_TWO']
    key = 'data.txt'
    new_key = 'processed_data.txt'
    
    obj = s3.get_object(Bucket=source_bucket, Key=key)
    data = obj['Body'].read()

    s3.put_object(Bucket=target_bucket, Key=new_key, Body=data)
    return {'status': 'processed', 'bucket': target_bucket, 'key': new_key}

