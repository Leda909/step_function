import boto3
import os

def handler(event, context):
    s3 = boto3.client('s3')
    bucket = os.environ['BUCKET_TWO']
    key = 'processed_data.txt'
    
    obj = s3.get_object(Bucket=bucket, Key=key)
    data = obj['Body'].read().decode('utf-8')
    print(f"Data received in final lambda: {data}")
    
    return {'status': 'forwarded'}

